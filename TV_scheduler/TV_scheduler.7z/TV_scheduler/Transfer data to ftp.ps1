﻿Rename-Item -Path ".\Result\Simple.xls" -NewName ("AVITO TV event level "+("{0:yyyyMMdd}" -f [datetime](get-date).adddays(-4))+".xls")

$dir = "./TV_event_data"
$server = "russia.mecglobal.com"
$filelist = "test.xml"   
$user = "AVITO_rw"
$password = "G18B4tbg"

"open $server
user $user $password
binary  
cd $dir     
" +
($filelist.split(' ') | %{ "put ""$_""`n" }) | ftp -i -in